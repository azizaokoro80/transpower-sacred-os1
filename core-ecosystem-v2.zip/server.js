import express from 'express';
import sendEmail from './backend/api/sendEmail.js';

const app = express();
app.use(express.json());
app.use('/api/sendEmail', sendEmail);

app.use(express.static('frontend'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
