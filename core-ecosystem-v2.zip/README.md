# ThriveBaltimore Core Ecosystem

This is the initial repo for the backend and microservices powering ThriveBaltimore.