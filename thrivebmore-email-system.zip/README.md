# ThriveBMore Email System

This is the backend and frontend for a contact form email sender using Node.js and Nodemailer.
